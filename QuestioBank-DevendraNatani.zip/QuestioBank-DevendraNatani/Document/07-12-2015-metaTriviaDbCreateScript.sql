CREATE DATABASE `meta_trivia_database`;

USE `meta_trivia_database`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `blocking_reason` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `image_url` varchar(100) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  `lastloggedintime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_name` varchar(255) DEFAULT NULL,
  `user_status` varchar(40) DEFAULT 'Unblocked',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`)
);


CREATE TABLE `answer_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);


CREATE TABLE `answervotes` (
  `a_vote_id` int(11) NOT NULL AUTO_INCREMENT,
  `answer_id` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`a_vote_id`)
);


CREATE TABLE `popularity` (
  `popularity_id` int(11) NOT NULL AUTO_INCREMENT,
  `down_votes` int(11) DEFAULT NULL,
  `up_votes` int(11) DEFAULT NULL,
  PRIMARY KEY (`popularity_id`)
);


CREATE TABLE `question_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `closing_reason` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);


CREATE TABLE `questionvotes` (
  `q_vote_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`q_vote_id`)
);


CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `UK_1r1tyf6uga9k6jwdqnoqwtk2a` (`tag_name`)
);


CREATE TABLE `question` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `question_body` text,
  `question_title` varchar(255) DEFAULT NULL,
  `popularity_id` int(11) NOT NULL,
  `question_detail_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`question_id`),
  KEY `FK_87q0sy9fb56pd4pw5dsx4wtx3` (`popularity_id`),
  KEY `FK_8mgf66u4a9v7tftptmvmrk5xt` (`question_detail_id`),
  KEY `FK_os8bn3xr2x2owjn69es4hcxgs` (`user_id`),
  CONSTRAINT `FK_87q0sy9fb56pd4pw5dsx4wtx3` FOREIGN KEY (`popularity_id`) REFERENCES `popularity` (`popularity_id`),
  CONSTRAINT `FK_8mgf66u4a9v7tftptmvmrk5xt` FOREIGN KEY (`question_detail_id`) REFERENCES `question_detail` (`id`),
  CONSTRAINT `FK_os8bn3xr2x2owjn69es4hcxgs` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
);


CREATE TABLE `question_tag` (
  `question_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`question_id`,`tag_id`),
  KEY `FK_mgv05gh8lk2eghrvcgakd4oqs` (`tag_id`),
  CONSTRAINT `FK_mgv05gh8lk2eghrvcgakd4oqs` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`),
  CONSTRAINT `FK_nohinfm7r87x757nhj9sf4ef2` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`)
);


CREATE TABLE `answer` (
  `answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `answer_body` text,
  `post_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `answer_Detail_id` int(11) NOT NULL,
  `popularity_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`answer_id`),
  KEY `FK_qoeiwrfbvfitjmissx5swttne` (`answer_Detail_id`),
  KEY `FK_ssma410wptdhtcgfgkqwsnqee` (`popularity_id`),
  KEY `FK_eix9du6u2r4wxwu415wq8yb99` (`question_id`),
  KEY `FK_ilrlwe1trc8dyqaius89vprop` (`user_id`),
  CONSTRAINT `FK_eix9du6u2r4wxwu415wq8yb99` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`),
  CONSTRAINT `FK_ilrlwe1trc8dyqaius89vprop` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FK_qoeiwrfbvfitjmissx5swttne` FOREIGN KEY (`answer_Detail_id`) REFERENCES `answer_detail` (`id`),
  CONSTRAINT `FK_ssma410wptdhtcgfgkqwsnqee` FOREIGN KEY (`popularity_id`) REFERENCES `popularity` (`popularity_id`)
);

INSERT INTO `meta_trivia_database`.`tag` (`tag_id`, `tag_name`) VALUES (1, 'JAVA');
INSERT INTO `meta_trivia_database`.`user` (`email`, `image_url`, `is_admin`, `user_name`) VALUES ('manish.sharma2@metacube.com',
'https://lh6.googleusercontent.com/-FN8d5yS_ZX4/AAAAAAAAAAI/AAAAAAAAAFk/ex2HuzBigvs/photo.jpg', 1, 'Manish Sharma');