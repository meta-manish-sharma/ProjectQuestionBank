/**Service class implementation for users
 * 
 * @author Team Devendra
 */
package com.metacube.QuestionBank.service.impl;


import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.metacube.QuestionBank.dao.UserDao;
import com.metacube.QuestionBank.exception.UserDoesNotExistExeption;
import com.metacube.QuestionBank.model.User;
import com.metacube.QuestionBank.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	//userDao object
	@Autowired(required = true)
	private UserDao userDao;
	
	//logger object
	private static Logger logger = Logger.getLogger(UserServiceImpl.class);

	private static final String MSG="Exception in UserServiceImpl";
	
	/**
	 * method to add user
	 */
	@Transactional
	public boolean addUser(User user) {
		
		boolean flag = false;
		
		try {
			userDao.addUser(user);
			flag = true;
			
		} catch (Exception e) {
			logger.error(Thread.currentThread().getStackTrace()[2].getLineNumber());
			logger.error(MSG, e);
			e.printStackTrace();
		}
		
		return flag;
	}
	
	/**
	 * method to list the users
	 */
	@Transactional
	public Set<User> listUsers() {
		Set<User> users = null;
		
		try {
			users = userDao.listUsers();
		} catch (Exception e) {
			logger.error(Thread.currentThread().getStackTrace()[2].getLineNumber());
			logger.error(MSG, e);
			e.printStackTrace();
		}
		return users;
	}

	/**
	 * method to get the user by email
	 */
	@Transactional
	public User getUserByEmail(String email) {
		
		User user = null;
		
		try {
			user = userDao.getUser(email);
			
		} catch (Exception e) {
			logger.error(Thread.currentThread().getStackTrace()[2].getLineNumber());
			logger.error(MSG, e);
			e.printStackTrace();
		}
		return user;
	}
	
	
	/**
	 * to block the user by Id
	 */
	@Transactional
	public boolean blockUser(int userId) throws UserDoesNotExistExeption {
		boolean flag = false;
		User user = null;
		try {
			user = userDao.getUserById(userId);
		} catch (Exception e) {
			logger.error(Thread.currentThread().getStackTrace()[2].getLineNumber());
			logger.error(MSG, e);
			e.printStackTrace();
		}
		
		if(user == null) {
			throw new UserDoesNotExistExeption("User Does Not Exists With Id : " + userId);
		} 
		try {
			if(user.getUserStatus().equals("blocked")){
				user.setUserStatus("Unblocked");
			} else {
				user.setUserStatus("blocked");
			} 
					
			userDao.addUser(user);
			flag = true;
		} catch (Exception e) {
			logger.error(Thread.currentThread().getStackTrace()[2].getLineNumber());
			logger.error(MSG, e);
			e.printStackTrace();
		}
		
		return flag;
	}
	
	/**
	 * method to get the user by userId
	 */
	@Transactional
	public User getUserByUserId(int userId) {
		User user = null;
		
		try {
			user = userDao.getUserById(userId);
		} catch (Exception e) {
			logger.error(Thread.currentThread().getStackTrace()[2].getLineNumber());
			logger.error(MSG, e);
			e.printStackTrace();
		} 
		return user;
	}

	/**
	 * method to make admin to an user 
	 */
	@Transactional
	public boolean addAdmin(int userId) throws UserDoesNotExistExeption {
		boolean flag = false;
		
		User user = null;
		try {
			user = userDao.getUserById(userId);
		} catch (Exception e) {
			logger.error(Thread.currentThread().getStackTrace()[2].getLineNumber());
			logger.error(MSG, e);
			e.printStackTrace();
		}
		
		
		if(user == null) {
			throw new UserDoesNotExistExeption("User Does Not Exists With Id : " + userId);
		} 
		
		try {
			user.setIsAdmin(!(user.getIsAdmin()));
			flag = true;
		} catch (Exception e) {
			logger.error(Thread.currentThread().getStackTrace()[2].getLineNumber());
			logger.error(MSG, e);
			e.printStackTrace();
		}
		
		return flag;
	}

	/**
	 * method to get the List of user's name
	 */
	
	@Transactional
	public List<String> getUserList() {
		return userDao.getUserList();
	}

	@Transactional
	public List<User> getUsers(int offset, int noOfRecords) {
        List<User> users = null;
		
		try {
			users = userDao.getUsers(offset,noOfRecords);
		} catch (Exception e) {
			logger.error(Thread.currentThread().getStackTrace()[2].getLineNumber());
			logger.error(MSG, e);
			e.printStackTrace();
		}
		return users;
	}

}
