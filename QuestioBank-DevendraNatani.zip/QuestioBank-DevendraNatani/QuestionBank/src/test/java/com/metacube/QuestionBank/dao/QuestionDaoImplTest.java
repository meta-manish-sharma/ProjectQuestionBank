package com.metacube.QuestionBank.dao;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.metacube.QuestionBank.model.Popularity;
import com.metacube.QuestionBank.model.Question;
import com.metacube.QuestionBank.model.QuestionDetail;
import com.metacube.QuestionBank.model.Tag;
import com.metacube.QuestionBank.model.User;
@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(locations={"file:src/main/webapp/WEB-INF/questionbank-servlet.xml"})
public class QuestionDaoImplTest {

	
	@Autowired
	private QuestionDao questionDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private TagDao tagDao;
	private Question question ;
	private User user ;
	Question question2;
	private Tag tagJAVA;
	
	private boolean expected = true;

	@Transactional
	@Before
	public void setUp() {
		user =new User();
		user.setUserName("test");
		user.setEmail("test@metacube.com");
		
		userDao.addUser(user);
		System.out.println(user);
		question = new Question();
		Popularity popularity = new Popularity();
		question.setPopularity(popularity);
		
		QuestionDetail questionDetail = new QuestionDetail();
		question.setQuestionDetail(questionDetail);
		
		question.setQuestionBody("test");
		question.setQuestionTitle("test");
		Tag tagHTML = tagDao.getTagByName("HTML");
		question.setUser(user);
		if(tagHTML == null) {
			tagHTML = new Tag();
			int tagId = tagDao.addTag(tagHTML);
			tagHTML = tagDao.getTag(tagId);
		}
		
		Set<Tag> tagList = new HashSet<Tag>();
		tagList.add(tagHTML);
		question.setTagList(tagList);
		
		
		question2 = new Question();
		Popularity popularity2 = new Popularity();
		question2.setPopularity(popularity2);
		
		QuestionDetail questionDetail2 = new QuestionDetail();
		question2.setQuestionDetail(questionDetail2);
		
		question2.setQuestionBody("test");
		question2.setQuestionTitle("test");
		tagJAVA = tagDao.getTagByName("JAVA");
		question2.setUser(user);
		if(tagJAVA == null) {
			tagJAVA = new Tag();
			int tagId = tagDao.addTag(tagJAVA);
			tagJAVA = tagDao.getTag(tagId);
		}
		
		Set<Tag> tagList2 = new HashSet<Tag>();
		tagList2.add(tagJAVA);
		question2.setTagList(tagList2);
		
	}
	
	@Transactional
	@Test
	public void testAddQuestion() {
		boolean output = false;
		questionDao.addQuestion(question);
		int questionId = question.getQuestionId();
		if (questionId != -1) {
			output = true;
		}
	
		assertEquals(expected , output);
		
		
	}

	@Transactional
	@Test
	public void testListQuestions() {

		int size = questionDao.listQuestions().size() + 1;
	
		questionDao.addQuestion(question);
	
		assertEquals(size, questionDao.listQuestions().size());
	}
	
	@Transactional
	@Test
	public void testListQuestionsByTagId() {		
	
		
		int tagId = tagJAVA.getTagId();
		int size1 = questionDao.listQuestions(tagId).size() + 1;
		
		questionDao.addQuestion(question2);
	    assertEquals(size1, questionDao.listQuestions(tagId).size());
	}
	
	@Transactional
	@Test
	public void testGetQuestionsQuestionId() {
		questionDao.addQuestion(question);		
		Question questionTest = questionDao.getQuestionById(question.getQuestionId());
		assertEquals(question, questionTest);
	}

}
